<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/





//Route::redirect('lara-admin','login');
Route::get('/','HomeController@index')->name('welcome');
Route::post('/reservation','ReservationController@reserve')->name('reservation.reserve');
Route::post('/contact','ContactController@sendMessage')->name('contact.send');

Route::auth();



Route::group(['prefix'=>'admin','middleware'=>'auth','namespace'=>'Admin'], function (){
    Route::get('dashboard', 'DashboardController@index')->name('admin.dashboard');
    Route::resource('slider','SliderController');
	    Route::get('admin/slider/{slider}/edit', 'SliderController@edit')->name('slider.edit');
			   Route::post('admin/slider/{slider}/edit', 'SliderController@update')->name('slider.update');

	   //Route::post('admin/slider/{slider}', 'SliderController@update')->name('slider.update');
	    Route::get('admin/slider', 'SliderController@index')->name('slider.index');
			    Route::post('admin/slider', 'SliderController@store');
			    //Route::post('admin/slider', 'SliderController@update');
	   Route::post('admin/slider/{slider}', 'SliderController@destroy')->name('slider.destroy');

	   Route::get('admin/slider/create', 'SliderController@create')->name('slider.create');
	   Route::post('admin/slider', 'SliderController@store')->name('slider.store');

    Route::resource('category','CategoryController');
	
		   Route::get('admin/category/create', 'CategoryController@create')->name('category.create');
	   Route::post('admin/category', 'CategoryController@store')->name('category.store');
	    Route::get('admin/category', 'CategoryController@index')->name('category.index');
	   Route::post('admin/category/{category}', 'CategoryController@destroy')->name('category.destroy');
	    Route::get('admin/category/{category}/edit', 'CategoryController@edit')->name('category.edit');
			   Route::post('admin/category/{category}/edit', 'CategoryController@update')->name('category.update');

    Route::resource('item','ItemController');
	  Route::get('admin/item/create', 'ItemController@create')->name('item.create');
	   Route::post('admin/item', 'ItemController@store')->name('item.store');
	    Route::get('admin/item', 'ItemController@index')->name('item.index');
	   Route::post('admin/item/{item}', 'ItemController@destroy')->name('item.destroy');
	    Route::get('admin/item/{item}/edit', 'ItemController@edit')->name('item.edit');
			   Route::post('admin/item/{item}/edit', 'ItemController@update')->name('item.update');
			       Route::resource('reservation','ReservationController');
      Route::post('reservation/{id}','ReservationController@status')->name('reservation.status');
    	   
 Route::get('reservation','ReservationController@index')->name('reservation.index');
 Route::delete('reservation/{id}','ReservationController@destory')->name('reservation.destory');


    Route::get('contact','ContactController@index')->name('contact.index');

    Route::get('contact/{id}','ContactController@show')->name('contact.show');
    Route::post('contact/{id}','ContactController@destroy')->name('contact.destroy');
});


