<?php $__env->startSection('content'); ?>
    <section class="hero text-center">
        <br/>
        <br/>
        <br/>
        <br/>
        <h2>
            <strong>
                Hey! Welcome to Online Books store
            </strong>
        </h2>
        <br>
        <a href="<?php echo e(url('/shirts')); ?>">
            <button class="button large">Check out My BOOKS</button>
        </a>
    </section>
    <br/>
    <div class="subheader text-center">
        <h2>
            WELCOME&rsquo;s SECOND HAND BOOKS
        </h2>
    </div>

    <!-- Latest SHirts -->
    <div class="row">
        <?php $__empty_1 = true; foreach($shirts->chunk(4) as $chunk): $__empty_1 = false; ?>
            <?php foreach($chunk as $shirt): ?>
            <div class="small-3 medium-3 large-3 columns">
 <div class="item-wrapper">
                    <div class="img-wrapper">
                        <a href="<?php echo e(route('cart.addItem',$shirt->id)); ?>"
						class="button expanded add-to-cart">
                            Add to Cart
                        </a>
                        <a href="#">
                            <img src="<?php echo e(asset("images/$shirt->image")); ?>"/>
                        </a>
                    </div>
                
                        <h3>
						<?php echo e($shirt->name); ?>

                        </h3>
                    
                    <h5>
					 $<?php echo e($shirt->price); ?> 
                       
                    </h5>
                    <p>
					<?php echo e($shirt->description); ?>

                    </p>
                </div>

            </div>
            <?php endforeach; ?> 
        <?php endforeach; if ($__empty_1): ?>
            <h3>No BOOks</h3>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <br>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>