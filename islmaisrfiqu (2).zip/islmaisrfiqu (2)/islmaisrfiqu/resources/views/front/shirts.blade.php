@extends('layout.main')

@section('title','BOOKS')
@section('content')
   
        <!-- products listing -->
         <!-- Latest SHirts -->
        <div class="row">
							<a href="{{ route('home') }}" class="btn btn-danger">Back</a>

		 @forelse($shirts as $shirt)
          
            <div class="small-3 medium-3 large-3 columns">


 <div class="item-wrapper">
                    <div class="img-wrapper">
						
                        <a href="{{route('cart.addItem',$shirt->id)}}"
						class="button expanded add-to-cart">
                            Add to Cart
                        </a>
                        <a href="#">
                            <img src="{{url('images',$shirt->image)}}"/>
                        </a>
                    </div>
                  
                        <h3>
                        <h3>
						{{$shirt->name}}
                        </h3>
                  
                    <h5>
					 ${{$shirt->price}} 
                       
                    </h5>
                    <p>
					{{$shirt->description}}
                    </p>
                </div>

            </div>
            
       @empty
	   <h3>No BOOKs</h3>
	   @endforelse
		   </div>
@endsection

