<?php
//use App\Order;
use App\Order;
use App\Products;
namespace App\Http\Controllers;
use Gloudemans\Shoppingcart\Facades\Cart;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckoutController extends Controller
{
   
 public function shipping()
    {
        return view('front.shipping-info');
    }
  public function payment()
    {
        return view('front.payment');
    }
 public function storePayment(Request $request)
    {
		//$amt=Cart::total();
		//dd($amt);
	 
          \Stripe\Stripe::setApiKey("sk_test_M8hfDnQwXx36Lm8qJ2zWjVDP");

// Get the credit card details submitted by the form
        $token = $request->stripeToken;

// Create a charge: this will charge the user's card
        try {
           $charge = \Stripe\Charge::create(array(
               "amount" => Cart::total()*100, // Amount in cents
              "currency" => "usd",
                "source" => $token,
               "description" => "Example charge"
            ));
       } 
	   catch (\Stripe\Error\Card $e) {
            // The card has been declined
        }
		 
	

  $user=Auth::user();
        $order=$user->orders()->create([
            'total'=>Cart::total(),
            'delivered'=>0
        ]);

        $cartItems=Cart::content();
        foreach ($cartItems as $cartItem){
            $order->orderItems()->attach($cartItem->id,[
                'qty'=>$cartItem->qty,
                'total'=>$cartItem->qty*$cartItem->price
            ]);
        }
 
	}
   
	
	}



